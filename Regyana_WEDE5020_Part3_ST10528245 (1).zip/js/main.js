document.addEventListener("DOMContentLoaded", () => {
    const dateField = document.getElementById("date");
    if (dateField) dateField.min = new Date().toISOString().split("T")[0];
    const year = document.querySelectorAll(".current-year");
    year.forEach(el => el.textContent = new Date().getFullYear());

    // Animated reveal using IntersectionObserver.
    const revealItems = document.querySelectorAll(".reveal");
    if ("IntersectionObserver" in window) {
        const observer = new IntersectionObserver(entries => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add("visible");
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12 });
        revealItems.forEach(item => observer.observe(item));
    } else {
        revealItems.forEach(item => item.classList.add("visible"));
    }

    // Accordion.
    document.querySelectorAll(".accordion-button").forEach(button => {
        button.addEventListener("click", () => {
            const panel = document.getElementById(button.getAttribute("aria-controls"));
            const expanded = button.getAttribute("aria-expanded") === "true";
            button.setAttribute("aria-expanded", String(!expanded));
            panel.hidden = expanded;
        });
    });

    // Tabs.
    const tabs = document.querySelectorAll("[role='tab']");
    tabs.forEach(tab => {
        tab.addEventListener("click", () => {
            const group = tab.closest(".tabs");
            group.querySelectorAll("[role='tab']").forEach(t => {
                t.setAttribute("aria-selected", "false");
                t.classList.remove("active");
            });
            group.querySelectorAll("[role='tabpanel']").forEach(panel => panel.hidden = true);
            tab.setAttribute("aria-selected", "true");
            tab.classList.add("active");
            document.getElementById(tab.getAttribute("aria-controls")).hidden = false;
        });
    });

    // Services search and category filter.
    const search = document.getElementById("service-search");
    const filter = document.getElementById("service-filter");
    const cards = [...document.querySelectorAll(".service-item")];
    const empty = document.getElementById("service-empty");

    function filterServices() {
        if (!cards.length) return;
        const query = (search?.value || "").trim().toLowerCase();
        const category = filter?.value || "all";
        let shown = 0;
        cards.forEach(card => {
            const text = card.textContent.toLowerCase();
            const categories = card.dataset.category || "";
            const matchesText = text.includes(query);
            const matchesCategory = category === "all" || categories.includes(category);
            const show = matchesText && matchesCategory;
            card.hidden = !show;
            if (show) shown++;
        });
        if (empty) empty.hidden = shown !== 0;
    }
    search?.addEventListener("input", filterServices);
    filter?.addEventListener("change", filterServices);

    // Gallery lightbox.
    const lightbox = document.getElementById("lightbox");
    const lightboxImage = document.getElementById("lightbox-image");
    const lightboxCaption = document.getElementById("lightbox-caption");
    const closeLightbox = document.querySelector("[data-close-lightbox]");
    document.querySelectorAll("[data-lightbox]").forEach(trigger => {
        trigger.addEventListener("click", () => {
            if (!lightbox) return;
            lightboxImage.src = trigger.dataset.src || trigger.src;
            lightboxImage.alt = trigger.alt;
            lightboxCaption.textContent = trigger.dataset.caption || trigger.alt;
            lightbox.showModal ? lightbox.showModal() : lightbox.setAttribute("open", "");
        });
    });
    function closeBox() {
        if (!lightbox) return;
        if (lightbox.close) lightbox.close();
        else lightbox.removeAttribute("open");
    }
    closeLightbox?.addEventListener("click", closeBox);
    lightbox?.addEventListener("click", e => {
        if (e.target === lightbox) closeBox();
    });
    document.addEventListener("keydown", e => {
        if (e.key === "Escape") closeBox();
    });

    // Enquiry form: client-side validation and dynamic estimate.
    const enquiryForm = document.getElementById("enquiry-form");
    if (enquiryForm) {
        const result = document.getElementById("enquiry-result");
        const service = document.getElementById("service");
        const guests = document.getElementById("guests");
        const date = document.getElementById("date");

        enquiryForm.addEventListener("submit", event => {
            event.preventDefault();
            clearErrors(enquiryForm);
            let valid = true;
            if (!validateRequired(enquiryForm.querySelector("#fullname"), "Please enter your full name.")) valid = false;
            if (!validateEmail(enquiryForm.querySelector("#email"))) valid = false;
            if (!validatePhone(enquiryForm.querySelector("#phone"))) valid = false;
            if (!service.value) { showError(service, "Please select a service."); valid = false; }
            if (!enquiryForm.querySelector("#message").value.trim()) {
                showError(enquiryForm.querySelector("#message"), "Please describe your enquiry."); valid = false;
            }
            if (!valid) return;

            const guestCount = Math.max(1, Number(guests.value || 1));
            const estimates = {
                accommodation: `Accommodation starts at approximately R600 per night. For ${guestCount} guest(s), the starting estimate is R${600 * guestCount} per night.`,
                breakfast: `Breakfast is approximately R70 per person. For ${guestCount} guest(s), the starting estimate is R${70 * guestCount}.`,
                catering: "Catering is quoted according to the event requirements, menu and number of guests.",
                decoration: "Event décor is quoted according to the type, size and requirements of the event.",
                party: "Party and celebration services are quoted after the event requirements are confirmed.",
                "baby-shower": "Baby shower services are quoted according to catering, décor and guest requirements.",
                other: "We will review your requirements and respond with availability and pricing."
            };
            result.textContent = estimates[service.value] || estimates.other;
            result.hidden = false;
            result.focus();
        });
    }

    // Contact form: validate, compile and open recipient email.
    const contactForm = document.getElementById("contact-form");
    contactForm?.addEventListener("submit", event => {
        event.preventDefault();
        clearErrors(contactForm);
        let valid = true;
        const name = contactForm.querySelector("#contact-name");
        const email = contactForm.querySelector("#contact-email");
        const phone = contactForm.querySelector("#contact-phone");
        const subject = contactForm.querySelector("#subject");
        const message = contactForm.querySelector("#contact-message");

        if (!validateRequired(name, "Please enter your full name.")) valid = false;
        if (!validateEmail(email)) valid = false;
        if (!validatePhone(phone, true)) valid = false;
        if (!subject.value) { showError(subject, "Please select a subject."); valid = false; }
        if (message.value.trim().length < 10) {
            showError(message, "Please enter a message of at least 10 characters."); valid = false;
        }
        if (!valid) return;

        const body = [
            `Name: ${name.value.trim()}`,
            `Email: ${email.value.trim()}`,
            `Phone: ${phone.value.trim() || "Not provided"}`,
            `Message type: ${subject.options[subject.selectedIndex].text}`,
            "",
            "Message:",
            message.value.trim()
        ].join("\n");
        window.location.href =
            `mailto:info@regyana.co.za?subject=${encodeURIComponent(subject.value ? subject.options[subject.selectedIndex].text : "General Enquiry")}&body=${encodeURIComponent(body)}`;
    });

    function validateRequired(field, message) {
        if (!field || !field.value.trim()) {
            showError(field, message);
            return false;
        }
        return true;
    }
    function validateEmail(field) {
        if (!field || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i.test(field.value.trim())) {
            showError(field, "Please enter a valid email address.");
            return false;
        }
        return true;
    }
    function validatePhone(field, optional = false) {
        if (!field) return false;
        const value = field.value.trim();
        if (!value && optional) return true;
        if (!/^\+?[0-9\s()\-]{7,20}$/.test(value)) {
            showError(field, "Please enter a valid phone number.");
            return false;
        }
        return true;
    }
    function showError(field, message) {
        if (!field) return;
        field.classList.add("invalid");
        field.setAttribute("aria-invalid", "true");
        let error = document.getElementById(`${field.id}-error`);
        if (!error) {
            error = document.createElement("span");
            error.id = `${field.id}-error`;
            error.className = "field-error";
            field.insertAdjacentElement("afterend", error);
        }
        error.textContent = message;
    }
    function clearErrors(form) {
        form.querySelectorAll(".invalid").forEach(field => {
            field.classList.remove("invalid");
            field.removeAttribute("aria-invalid");
        });
        form.querySelectorAll(".field-error").forEach(error => error.remove());
    }
});
